---
title: "Tour 2 – Extended: Lambaré – Isla San Francisco – Banco San Miguel – Bahía & Asunción-Panorama"
date: 2025-06-25
route:
  - [-25.331, -57.602]
  - [-25.323, -57.615]
  - [-25.310, -57.620]
  - [-25.297, -57.629]
  - [-25.331, -57.602]
---

**Strecke:** ca. 32–34 km  
**Dauer:** 4,5–5 Stunden  
**Highlight:** Flussinsel, Naturreservat, Innenstadt-Blick vom Wasser  

**Route:**  
1. Lambaré → flussaufwärts zur Isla San Francisco (Erkundung)  
2. Weiterfahrt zur Bahía de Asunción, dann Banco San Miguel  
3. Umrundung des Naturreservats (langsamer Bereich)  
4. Fotostopp mit Skyline-Panorama von Asunción  
5. Rückfahrt auf dem Chaco-Ufer nach Lambaré  

**Tiere:**  
- Störche, Ibisse, Wildenten, Eisvögel  
- Wasserechsen, Kaimane  
- Brüllaffen (gelegentlich)  
