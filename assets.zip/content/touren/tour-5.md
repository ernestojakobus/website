---
title: "Tour 5 – Sunset-Rundkurs: Isla San Francisco & Bahía Asunción"
date: 2025-06-25
route:
  - [-25.331, -57.602]    # Lambaré
  - [-25.323, -57.615]    # Isla San Francisco
  - [-25.297, -57.629]    # Bahía de Asunción
  - [-25.310, -57.620]    # Rückfahrt Chaco-Ufer
  - [-25.331, -57.602]    # zurück
---
**Startzeit:** 16:00–16:30 Uhr  
**Dauer:** 3–4 Stunden  
**Strecke:** 25–30 km  
**Highlight:** Goldene Stunde, Skyline-Panorama  

**Route:**  
1. Lambaré → Isla San Francisco  
2. Rundfahrt um die Insel (Beobachtung)  
3. Weiterfahrt zur Bahía de Asunción  
4. Wenden in der goldenen Stunde  
5. Rückfahrt mit Cocktail an Bord  

**Ideal für:**  
- Fotografen, Paare, kleine Gruppen  
- Entspannte Atmosphäre  
