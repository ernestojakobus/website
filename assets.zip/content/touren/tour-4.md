---
title: "Tour 4 – Sunrise-Expedition: Lambaré → Río Salado & Vogelbeobachtung"
date: 2025-06-25
route:
  - [-25.331, -57.602]    # Lambaré
  - [-25.303, -57.630]    # Flussabwärts Salado
  - [-25.305, -57.625]    # Im Salado
  - [-25.331, -57.602]    # zurück
---
**Startzeit:** ca. 5:30 Uhr  
**Dauer:** 2,5–3,5 Stunden  
**Strecke:** ca. 25–30 km  
**Highlight:** Sonnenaufgang, Vogelwelt beim Erwachen  

**Route:**  
1. Abfahrt Lambaré in der Morgendämmerung  
2. Flussabwärts zur Mündung des Río Salado  
3. Langsame Fahrt im Salado (spiegelglattes Wasser)  
4. Kaffeepause an Bord  
5. Rückfahrt gegen 8:30 Uhr  

**Tiere & Stimmung:**  
- Reiher, Enten, Eisvögel  
- Nebelverhangene Uferlandschaft  
- Magisches Morgenlicht  
