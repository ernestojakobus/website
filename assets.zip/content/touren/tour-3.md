---
title: "Tour 3 – Extended: Lambaré – Chaco’i – Feuchtgebiete – Río Confuso (Einmündung)"
date: 2025-06-25
route:
  - [-25.331, -57.602]    # Lambaré
  - [-25.278, -57.638]    # Chaco’i
  - [-25.291, -57.627]    # Feuchtgebiete
  - [-25.285, -57.632]    # Río Confuso
  - [-25.331, -57.602]    # zurück
---
**Strecke:** ca. 35 km  
**Dauer:** 4,5–5 Stunden  
**Highlight:** Chaco-Feuchtgebiete, Sumpfvögel, Nebenfluss entdecken  

**Route:**  
1. Lambaré → Querung nach Chaco’i  
2. Fahrt entlang von Lagunen und Mangroven-Ufern  
3. Nordwärts zur Einmündung des Río Confuso  
4. Erkundung des Confuso-Nebenflusses  
5. Rückfahrt mit Pause auf Sandbank  

**Tiere:**  
- Reiherkolonien, Limikolen, Greifvögel  
- Schildkröten, große Echsen  
- Capybaras an der Confuso-Mündung  
