---
title: "Tour 6 – Feierabend-Fluss-Lounge: Lambaré → Chaco’i Ufer mit Sundowner"
date: 2025-06-25
route:
  - [-25.331, -57.602]    # Lambaré
  - [-25.278, -57.638]    # Chaco’i
  - [-25.331, -57.602]    # zurück
---
**Startzeit:** 17:00–18:00 Uhr  
**Dauer:** 2,5–3 Stunden  
**Strecke:** 15–20 km  
**Highlight:** Sundowner, Chill-Out auf dem Wasser  

**Route:**  
1. Abfahrt Lambaré → Chaco’i-Ufer  
2. Ankern in geschützter Bucht  
3. Sundowner mit Musik & Drinks  
4. Rückfahrt im Zwielicht  

**Ideal für:**  
- Feierabend-Groups (2–6 Personen)  
- Leichte Snacks & Cocktails  
