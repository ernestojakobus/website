---
title: "Tour 1 – Extended: Lambaré – Río Salado – Chaco-Naturufer – Isla Pombero (Rundkurs)"
date: 2025-06-25
route:
  - [-25.331, -57.602]
  - [-25.303, -57.630]
  - [-25.295, -57.650]
  - [-25.298, -57.635]
  - [-25.331, -57.602]
---

**Strecke:** ca. 35 km  
**Dauer:** 4–5 Stunden  
**Highlight:** Flussmündung, Naturufer Chaco, einsame Flussinsel  

**Route:**  
1. Lambaré → flussabwärts zur Mündung des Río Salado  
2. Weiterfahrt etwa 5 km flussabwärts entlang des Chaco-Ufers  
3. Querung zur Isla Pombero (Picknick-Stopp möglich)  
4. Beobachtung der Uferfauna: Reiher, Capybaras, Kaimane  
5. Rückfahrt flussaufwärts nach Lambaré (mit Sonnenuntergang)  

**Tiere:**  
- Reiher, Kormorane, Jabirus  
- Capybaras, Wasserechsen, Schildkröten  
- Selten: Otter, Brüllaffen
